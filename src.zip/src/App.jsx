import { useState, useEffect } from 'react'
import Login from './pages/Login.jsx'
import BuscarPaciente from './pages/BuscarPaciente.jsx'
import PerfilMedico from './pages/PerfilMedico.jsx'
import RegistrarPaciente from './pages/RegistrarPaciente.jsx'

function App() {
  const [paginaActual, setPaginaActual] = useState(() => {
    const pacienteGuardado = localStorage.getItem('pacienteSeleccionado')
    const usuarioGuardado = localStorage.getItem('usuario')

    if (usuarioGuardado && pacienteGuardado) {
      return 'perfil'
    }

    if (usuarioGuardado) {
      return 'buscarPaciente'
    }

    return 'login'
  })

  const [pacienteSeleccionado, setPacienteSeleccionado] = useState(() => {
    const pacienteGuardado = localStorage.getItem('pacienteSeleccionado')
    return pacienteGuardado ? JSON.parse(pacienteGuardado) : null
  })

  const [usuario, setUsuario] = useState(() => {
    const usuarioGuardado = localStorage.getItem('usuario')
    return usuarioGuardado ? JSON.parse(usuarioGuardado) : null
  })

  function manejarLogin(datosUsuario) {
    setUsuario(datosUsuario)
    localStorage.setItem('usuario', JSON.stringify(datosUsuario))
    setPaginaActual('buscarPaciente')
  }

  function abrirPerfil(paciente) {
    setPacienteSeleccionado(paciente)
    localStorage.setItem('pacienteSeleccionado', JSON.stringify(paciente))
    setPaginaActual('perfil')
  }

  function abrirRegistroPaciente() {
    setPaginaActual('registrarPaciente')
  }

  function pacienteRegistrado(pacienteNuevo) {
    setPacienteSeleccionado(pacienteNuevo)
    localStorage.setItem('pacienteSeleccionado', JSON.stringify(pacienteNuevo))
    setPaginaActual('perfil')
  }

  function volverABuscarPaciente() {
    setPacienteSeleccionado(null)
    localStorage.removeItem('pacienteSeleccionado')
    setPaginaActual('buscarPaciente')
  }

  function cerrarSesion() {
    localStorage.removeItem('token')
    localStorage.removeItem('usuario')
    localStorage.removeItem('pacienteSeleccionado')

    setUsuario(null)
    setPacienteSeleccionado(null)
    setPaginaActual('login')
  }

  return (
    <>
      {paginaActual === 'login' && (
        <Login onLogin={manejarLogin} />
      )}

      {paginaActual === 'buscarPaciente' && (
        <BuscarPaciente
          usuario={usuario}
          onSeleccionarPaciente={abrirPerfil}
          onRegistrarPaciente={abrirRegistroPaciente}
          onCerrarSesion={cerrarSesion}
        />
      )}

      {paginaActual === 'registrarPaciente' && (
        <RegistrarPaciente
          usuario={usuario}
          onPacienteRegistrado={pacienteRegistrado}
          onVolver={() => setPaginaActual('buscarPaciente')}
        />
      )}

      {paginaActual === 'perfil' && pacienteSeleccionado && (
        <PerfilMedico
          paciente={pacienteSeleccionado}
          usuario={usuario}
          onBack={volverABuscarPaciente}
          onCerrarSesion={cerrarSesion}
        />
      )}
    </>
  )
}

export default App