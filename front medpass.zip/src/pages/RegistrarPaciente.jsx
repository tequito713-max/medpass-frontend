import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function RegistrarPaciente() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    curp: "",
    nombre: "",
    fechaNac: "",
    tipoSangre: "",
    telefono: "",
    email: "",
  });

  const [mensaje, setMensaje] = useState("");
  const [cargando, setCargando] = useState(false);

  const manejarCambio = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const registrarPaciente = async (e) => {
    e.preventDefault();
    setCargando(true);
    setMensaje("");

    try {
      const token = localStorage.getItem("token");

      const nuevoPaciente = {
        curp: form.curp,
        nombre: form.nombre,
        fechaNac: form.fechaNac,
        tipoSangre: form.tipoSangre,
        telefono: form.telefono,
        email: form.email,
      };

      const respuesta = await fetch("https://localhost:7121/api/Pacientes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(nuevoPaciente),
      });

      if (!respuesta.ok) {
        const errorTexto = await respuesta.text();
        throw new Error(errorTexto || "No se pudo registrar el paciente");
      }

      const pacienteCreado = await respuesta.json();

      setMensaje("Paciente registrado correctamente");

      setTimeout(() => {
        navigate(`/perfil-medico/${pacienteCreado.id}`);
      }, 1000);
    } catch (error) {
      console.error(error);
      setMensaje("Error: " + error.message);
    } finally {
      setCargando(false);
    }
  };

  return (
    <div className="registro-paciente-container">
      <div className="registro-card">
        <h2>Registrar nuevo paciente</h2>
        <p>Llena los datos para dar de alta al paciente.</p>

        <form onSubmit={registrarPaciente} className="registro-form">
          <label>CURP</label>
          <input
            type="text"
            name="curp"
            value={form.curp}
            onChange={manejarCambio}
            required
          />

          <label>Nombre completo</label>
          <input
            type="text"
            name="nombre"
            value={form.nombre}
            onChange={manejarCambio}
            required
          />

          <label>Fecha de nacimiento</label>
          <input
            type="date"
            name="fechaNac"
            value={form.fechaNac}
            onChange={manejarCambio}
            required
          />

          <label>Tipo de sangre</label>
          <input
            type="text"
            name="tipoSangre"
            value={form.tipoSangre}
            onChange={manejarCambio}
            placeholder="Ejemplo: O+"
          />

          <label>Teléfono</label>
          <input
            type="text"
            name="telefono"
            value={form.telefono}
            onChange={manejarCambio}
          />

          <label>Email</label>
          <input
            type="email"
            name="email"
            value={form.email}
            onChange={manejarCambio}
          />

          <button type="submit" disabled={cargando}>
            {cargando ? "Guardando..." : "Registrar paciente"}
          </button>

          <button
            type="button"
            className="btn-secundario"
            onClick={() => navigate("/buscar-paciente")}
          >
            Volver
          </button>
        </form>

        {mensaje && <p className="mensaje">{mensaje}</p>}
      </div>
    </div>
  );
}